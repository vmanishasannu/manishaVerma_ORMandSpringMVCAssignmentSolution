package com.gl.crm;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface CustomerServiceInterface {
	public List<Customer> findAll();

	public void save(Customer theBook);
	
	public void UpdateById(int theId);

	public void deleteById(int theId);

	public Customer findById(int id);
}
