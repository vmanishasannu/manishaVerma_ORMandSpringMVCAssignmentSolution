package com.gl.crm;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	CustomerServiceInterface customerServiceInterface;
	//http://localhost:8080/Customer_Relationship_Management/customer/list
	@RequestMapping("/list")
	public String loadHome(Model theModel) {
		// get Customer from db
		List<Customer> theCustomer = customerServiceInterface.findAll();
		 //add to the spring model
		theModel.addAttribute("Customer", theCustomer);// using addattribute we can access this in UI
		return "index";//jsp page
	}
	
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {

		// create model attribute to bind form data
		Customer theCustomer = new Customer();

		theModel.addAttribute("Customer", theCustomer);

		return "customer_form";
	}

	@PostMapping("/save")
	public String saveBook(@RequestParam("id") int id,
			@RequestParam("fname") String fname,@RequestParam("lname") String lname,@RequestParam("email") String email) {

		Customer theCustomer;
		if(id!=0)
		{
			theCustomer=customerServiceInterface.findById(id);
			theCustomer.setFname(fname);
			theCustomer.setLname(lname);
			theCustomer.setEmail(email);
		}
		else
			theCustomer=new Customer(fname, lname, email);
		// save the Customer
		customerServiceInterface.save(theCustomer);


		// use a redirect to prevent duplicate submissions
		return "redirect:/customer/list";

	}
	
	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("customerId") int theId,
			Model theModel) {

		// get the Book from the service
		Customer theCustomer = customerServiceInterface.findById(theId);


		// set Book as a model attribute to pre-populate the form
		theModel.addAttribute("Customer", theCustomer);

		// send over to our form
		return "customer_form";			
	}

	@RequestMapping("/delete")
	public String delete(@RequestParam("customerId") int theId) {
		// delete the Book
		customerServiceInterface.deleteById(theId);

		// redirect to /customer/list
		return "redirect:/customer/list";

	}


}
