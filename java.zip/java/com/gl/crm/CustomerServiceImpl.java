package com.gl.crm;

import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import javax.persistence.Entity;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;



@Repository
public class CustomerServiceImpl implements CustomerServiceInterface {
	private SessionFactory sessionFactory;

	// create session
	private Session session;
	
	@Autowired
	CustomerServiceImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
		try {
			session = sessionFactory.getCurrentSession();
		} catch (HibernateException e) {
			session = sessionFactory.openSession();
		}


	}

	@Transactional
	public List<Customer> findAll() {
		Transaction tx = session.beginTransaction();

		// find all the records from the database table
		List<Customer> customer=session.createQuery("from Customer",Customer.class).getResultList();
		tx.commit();

		return customer;
	}

	@Transactional
	public void save(Customer theCustomer) {
		Transaction tx = session.beginTransaction();

		// save transaction
		session.saveOrUpdate(theCustomer);


		tx.commit();
		
	}

	@Transactional
	public void UpdateById(int theId) {
		Transaction tx = session.beginTransaction();

		// get transaction
		Customer customer = session.get(Customer.class, theId);

		// delete record
		session.saveOrUpdate(customer);

		tx.commit();
		
	}

	@Transactional
	public void deleteById(int theId) {
		Transaction tx = session.beginTransaction();

		// get transaction
		Customer customer = session.get(Customer.class, theId);

		// delete record
		session.delete(customer);

		tx.commit();
		
	}

	@Override
	public Customer findById(int id) {
		Customer customer = new Customer();
		Transaction tx = session.beginTransaction();

		// find record with Id from the database table
		customer = session.get(Customer.class, id);

		tx.commit();


		return customer;
	}
	
}
